import React, { useEffect, useRef, useState, useCallback } from 'react';
import styled, { keyframes } from 'styled-components';

// Обновляем анимации
const slideUp = keyframes`
  from {
    transform: translateY(100%);
  }
  to {
    transform: translateY(0);
  }
`;

const slideDown = keyframes`
  from {
    transform: translateY(0);
  }
  to {
    transform: translateY(100%);
  }
`;

const fadeIn = keyframes`
  from {
    opacity: 0;
    backdrop-filter: blur(0);
  }
  to {
    opacity: 1;
    backdrop-filter: blur(8px);
  }
`;

const fadeOut = keyframes`
  from {
    opacity: 1;
    backdrop-filter: blur(8px);
  }
  to {
    opacity: 0;
    backdrop-filter: blur(0);
  }
`;

// Обновляем стили для Overlay
const Overlay = styled.div<{ isOpen: boolean; isClosing: boolean }>`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 1000;
  visibility: ${props => props.isOpen || props.isClosing ? 'visible' : 'hidden'};
  animation: ${props => props.isClosing ? fadeOut : fadeIn} 0.3s ease-in-out forwards;
  backdrop-filter: blur(8px);
  transition: visibility 0s ${props => props.isClosing ? '0.3s' : '0s'};
`;

// Обновляем стили для DrawerContainer
const DrawerContainer = styled.div<{ isOpen: boolean; isClosing: boolean }>`
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: var(--card-background);
  border-radius: var(--radius-lg) var(--radius-lg) 0 0;
  box-shadow: var(--shadow-lg);
  z-index: 1001;
  max-height: 90vh;
  overflow-y: auto;
  visibility: ${props => props.isOpen || props.isClosing ? 'visible' : 'hidden'};
  animation: ${props => props.isClosing ? slideDown : slideUp} 0.3s cubic-bezier(0.4, 0, 0.2, 1) forwards;
  border-top: 1px solid var(--border-color);
  will-change: transform;
  transition: visibility 0s ${props => props.isClosing ? '0.3s' : '0s'};

  /* Стилизация скроллбара */
  scrollbar-width: thin;
  scrollbar-color: var(--primary-color) transparent;

  &::-webkit-scrollbar {
    width: 6px;
  }

  &::-webkit-scrollbar-track {
    background: transparent;
  }

  &::-webkit-scrollbar-thumb {
    background-color: var(--primary-color);
    border-radius: 20px;
    border: 2px solid var(--card-background);
  }

  /* Добавляем плавное затухание контента внизу */
  &::after {
    content: '';
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 40px;
    background: linear-gradient(to top, var(--card-background), transparent);
    pointer-events: none;
  }
`;

const DrawerHeader = styled.div`
  padding: 20px 24px;
  border-bottom: 1px solid var(--border-color);
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: sticky;
  top: 0;
  background-color: var(--card-background);
  z-index: 2;
  border-radius: var(--radius-lg) var(--radius-lg) 0 0;
  backdrop-filter: blur(8px);
  
  /* Добавляем тень при скролле */
  &::after {
    content: '';
    position: absolute;
    bottom: -1px;
    left: 0;
    right: 0;
    height: 1px;
    background: var(--gradient-primary);
    opacity: 0.5;
  }
`;

const DrawerTitle = styled.h2`
  margin: 0;
  font-size: 1.25rem;
  font-weight: 600;
  color: var(--text-color);
  background: var(--gradient-primary);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  letter-spacing: -0.01em;
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  padding: 8px;
  cursor: pointer;
  color: var(--text-secondary);
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--radius);
  transition: all var(--transition-normal);
  width: 32px;
  height: 32px;

  &:hover {
    background-color: var(--hover-overlay);
    color: var(--primary-color);
    transform: rotate(90deg);
  }

  &:active {
    background-color: var(--active-overlay);
    transform: rotate(90deg) scale(0.95);
  }

  svg {
    width: 20px;
    height: 20px;
    stroke-width: 2.5;
    transition: stroke var(--transition-normal);
  }

  &:hover svg {
    stroke: var(--primary-color);
  }
`;

// Обновляем стили для DrawerContent
const DrawerContent = styled.div<{ isClosing: boolean }>`
  padding: 24px;
  min-height: 200px;
  position: relative;
  opacity: ${props => props.isClosing ? 0 : 1};
  transform: translateY(${props => props.isClosing ? '20px' : '0'});
  transition: all 0.3s ease-out;
  padding-bottom: 60px;
`;

interface BottomDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

const BottomDrawer: React.FC<BottomDrawerProps> = ({
  isOpen,
  onClose,
  title,
  children
}) => {
  const drawerRef = useRef<HTMLDivElement>(null);
  const [isClosing, setIsClosing] = useState(false);
  const [isVisible, setIsVisible] = useState(isOpen);
  const [shouldRender, setShouldRender] = useState(isOpen);

  // Обновляем видимость при изменении isOpen
  useEffect(() => {
    if (isOpen) {
      setShouldRender(true);
      // Небольшая задержка для анимации появления
      requestAnimationFrame(() => {
        setIsVisible(true);
        setIsClosing(false);
      });
    }
  }, [isOpen]);

  const handleClose = useCallback(() => {
    setIsClosing(true);
    // Ждем завершения анимации перед вызовом onClose
    setTimeout(() => {
      setIsClosing(false);
      setIsVisible(false);
      // Дополнительная задержка перед полным удалением из DOM
      setTimeout(() => {
        setShouldRender(false);
        onClose();
      }, 50);
    }, 300);
  }, [onClose]);

  // Обработка клика вне контейнера
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (drawerRef.current && !drawerRef.current.contains(event.target as Node)) {
        handleClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, handleClose]);

  // Предотвращение прокрутки body при открытом drawer
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // Обработка нажатия клавиши Escape
  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isOpen) {
        handleClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen, handleClose]);

  // Очистка при размонтировании
  useEffect(() => {
    return () => {
      setIsClosing(false);
      setIsVisible(false);
      setShouldRender(false);
      document.body.style.overflow = 'unset';
    };
  }, []);

  if (!shouldRender) return null;

  return (
    <>
      <Overlay 
        isOpen={isOpen} 
        isClosing={isClosing} 
        onClick={handleClose}
        style={{ 
          visibility: isVisible ? 'visible' : 'hidden',
          opacity: isVisible ? 1 : 0,
          transition: 'visibility 0s, opacity 0.3s ease-in-out'
        }}
      />
      <DrawerContainer 
        ref={drawerRef} 
        isOpen={isOpen} 
        isClosing={isClosing}
        style={{ 
          visibility: isVisible ? 'visible' : 'hidden',
          transform: isVisible ? 'translateY(0)' : 'translateY(100%)',
          transition: 'visibility 0s, transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
        }}
      >
        <DrawerHeader>
          <DrawerTitle>{title}</DrawerTitle>
          <CloseButton onClick={handleClose} aria-label="Close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </CloseButton>
        </DrawerHeader>
        <DrawerContent isClosing={isClosing}>
          {children}
        </DrawerContent>
      </DrawerContainer>
    </>
  );
};

export default BottomDrawer; 