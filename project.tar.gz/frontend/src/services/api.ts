import axios from 'axios';
import config from '../config';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { WriteOffReason, CreateWriteOffData } from '../types/writeOff';
import { socketService } from './socket';

// Создаем инстанс axios с базовыми настройками
const axiosInstance = axios.create({
    baseURL: process.env.REACT_APP_API_URL || '/api',
    headers: {
        'Content-Type': 'application/json'
    }
});

// Helper function to wrap socket emission in a Promise
const emitSocketEvent = (event: string, data: any): Promise<boolean> => {
    return new Promise((resolve) => {
        // Check if socket is connected first
        if (!socketService.isConnected()) {
            console.warn('⚠️ Socket not connected for event:', event);
            resolve(false);
            return;
        }
        
        // Use emitWithAck to get acknowledgement
        socketService.emitWithAck(event, data, (response: any) => {
            if (response && response.error) {
                console.error('❌ Socket event error:', response.error);
                resolve(false);
            } else {
                resolve(true);
            }
        });
    });
};

// API для работы со списаниями
const writeOffApi = {
    // Получение списка чатов
    getWriteOffChats: () => {
        console.log('=== 📡 Запрос списка чатов для списания ===');
        console.log('🔗 URL:', `${config.API_URL}/chats`);
        return axiosInstance.get('/chats').then(response => {
            console.log('✅ Ответ от сервера:', {
                status: response.status,
                data: response.data,
                headers: response.headers
            });
            return response;
        }).catch(error => {
            console.error('❌ Ошибка при запросе чатов:', {
                status: error.response?.status,
                data: error.response?.data,
                message: error.message,
                config: error.config
            });
            throw error;
        });
    },
    
    // Получение данных конкретного чата
    getWriteOffChat: (chatId: string) => {
        console.log('=== 📡 Запрос данных чата ===');
        console.log('🏠 Чат:', chatId);
        return axiosInstance.get(`/chats/${chatId}`);
    },
    
    // Получение списаний для чата (если есть)
    getWriteOffs: (chatId: string) => {
        console.log('=== 📡 Запрос списаний чата ===');
        console.log('🏠 Чат:', chatId);
        console.log('🔗 URL запроса:', `/write-offs/${chatId}`);
        console.log('🔗 Полный URL:', `${config.API_URL}/write-offs/${chatId}`);
        console.log('🔗 BASE URL:', process.env.REACT_APP_API_URL || '/api');
        
        return axiosInstance.get(`/write-offs/${chatId}`).then(response => {
            // Проверяем, что данные пришли в формате объекта с chatId в качестве ключа
            if (response.data && response.data[chatId]) {
                console.log('✅ Получены списания для чата:', response.data[chatId]);
                return { data: response.data[chatId] };
            }
            // Если данные пришли в формате массива, возвращаем как есть
            if (Array.isArray(response.data)) {
                console.log('✅ Получены списания в формате массива:', response.data);
                return { data: response.data };
            }
            // Если данные не найдены, возвращаем пустой массив
            console.log('ℹ️ Списания не найдены, возвращаем пустой массив');
            return { data: [] };
        }).catch(error => {
            // Если списаний нет (404), возвращаем пустой массив
            if (error.response?.status === 404) {
                console.log('ℹ️ Списания не найдены (404), возвращаем пустой массив');
                return { data: [] };
            }
            console.error('❌ Ошибка при запросе списаний:', {
                status: error.response?.status,
                data: error.response?.data,
                message: error.message
            });
            throw error;
        });
    },
    
    // Создание списания
    createWriteOff: (chatId: string, data: any) => {
        console.log('=== 📡 Создание списания ===');
        console.log('🏠 Чат:', chatId);
        console.log('📝 Данные:', data);

        // Пробуем сначала через WebSocket
        if (socketService.isConnected()) {
            console.log('🔌 Используем WebSocket для создания списания');
            
            // Для WebSocket-соединения мы будем использовать промис, который резолвится вручную
            return new Promise((resolve, reject) => {
                // Флаг для предотвращения двойного вызова resolve/reject
                let isResolved = false;
                
                // Обработчик успешного создания списания
                const successHandler = (response: any) => {
                    console.log('✅ Ответ WebSocket (создание):', response);
                    
                    // Предотвращаем дублирование ответа
                    if (isResolved) return;
                    isResolved = true;
                    
                    // Отписываемся от событий
                    socketService.unsubscribe('writeoff_update_sent');
                    socketService.unsubscribe('writeoff_update_error');
                    
                    // Возвращаем созданное списание
                    resolve(response.writeOffItem);
                };
                
                // Обработчик ошибки создания списания
                const errorHandler = (error: any) => {
                    console.error('❌ Ошибка WebSocket при создании списания:', error);
                    
                    // Предотвращаем дублирование ответа
                    if (isResolved) return;
                    isResolved = true;
                    
                    // Отписываемся от событий
                    socketService.unsubscribe('writeoff_update_sent');
                    socketService.unsubscribe('writeoff_update_error');
                    
                    // Отклоняем промис
                    reject(error);
                };
                
                // Подписываемся на события
                socketService.subscribe('writeoff_update_sent', successHandler);
                socketService.subscribe('writeoff_update_error', errorHandler);
                
                // Отправляем событие
                emitSocketEvent('writeoff_update', {
                    action: 'create',
                    chatId: chatId,
                    writeOffItem: {
                        name: data.name,
                        reason: data.reason,
                        quantity: data.quantity,
                        description: data.description || '',
                        unitType: data.unitType || 'шт'
                    }
                }).then((success: boolean) => {
                    if (!success && !isResolved) {
                        console.error('❌ Не удалось отправить сообщение через WebSocket');
                        isResolved = true;
                        
                        // Отписываемся от событий
                        socketService.unsubscribe('writeoff_update_sent');
                        socketService.unsubscribe('writeoff_update_error');
                        
                        // Fallback на REST API
                        fallbackToREST();
                    }
                }).catch((error: Error) => {
                    if (!isResolved) {
                        console.error('❌ Ошибка при отправке через WebSocket:', error);
                        isResolved = true;
                        
                        // Отписываемся от событий
                        socketService.unsubscribe('writeoff_update_sent');
                        socketService.unsubscribe('writeoff_update_error');
                        
                        // Fallback на REST API
                        fallbackToREST();
                    }
                });
                
                // Функция для fallback на REST API
                const fallbackToREST = () => {
                    console.log('⚠️ Fallback на REST API...');
                    axiosInstance.post(`/write-offs/${chatId}`, {
                        name: data.name,
                        reason: data.reason,
                        quantity: data.quantity,
                        description: data.description || '',
                        unitType: data.unitType || 'шт'
                    }).then(response => {
                        resolve(response.data);
                    }).catch(error => {
                        reject(error);
                    });
                };
                
                // Увеличиваем таймаут до 10 секунд
                setTimeout(() => {
                    if (!isResolved) {
                        console.warn('⚠️ Timeout на ожидание ответа от WebSocket');
                        isResolved = true;
                        
                        // Отписываемся от событий
                        socketService.unsubscribe('writeoff_update_sent');
                        socketService.unsubscribe('writeoff_update_error');
                        
                        // Fallback на REST API
                        fallbackToREST();
                    }
                }, 10000); // 10 секунд вместо 5
            });
        } else {
            console.log('📡 Используем REST API для создания списания');
            
            // Если WebSocket не подключен, используем REST API
            return axiosInstance.post(`/write-offs/${chatId}`, {
                name: data.name,
                reason: data.reason,
                quantity: data.quantity,
                description: data.description || '',
                unitType: data.unitType || 'шт'
            }).then(response => response.data);
        }
    },
    
    // Обновление списания
    updateWriteOff: (chatId: string, writeOffId: string, data: any) => {
        console.log('=== 📡 Обновление списания ===');
        console.log('🏠 Чат:', chatId);
        console.log('📝 ID списания:', writeOffId);
        console.log('📝 Данные:', data);

        // Пробуем сначала через WebSocket
        if (socketService.isConnected()) {
            console.log('🔌 Используем WebSocket для обновления списания');
            
            // Для WebSocket-соединения мы будем использовать промис, который резолвится вручную
            return new Promise((resolve, reject) => {
                // Флаг для предотвращения двойного вызова resolve/reject
                let isResolved = false;
                
                // Обработчик успешного обновления списания
                const successHandler = (response: any) => {
                    console.log('✅ Ответ WebSocket (обновление):', response);
                    
                    // Предотвращаем дублирование ответа
                    if (isResolved) return;
                    isResolved = true;
                    
                    // Отписываемся от событий
                    socketService.unsubscribe('writeoff_update_sent');
                    socketService.unsubscribe('writeoff_update_error');
                    
                    // Возвращаем обновленное списание
                    resolve(response.writeOffItem);
                };
                
                // Обработчик ошибки обновления списания
                const errorHandler = (error: any) => {
                    console.error('❌ Ошибка WebSocket при обновлении списания:', error);
                    
                    // Предотвращаем дублирование ответа
                    if (isResolved) return;
                    isResolved = true;
                    
                    // Отписываемся от событий
                    socketService.unsubscribe('writeoff_update_sent');
                    socketService.unsubscribe('writeoff_update_error');
                    
                    // Отклоняем промис
                    reject(error);
                };
                
                // Подписываемся на события
                socketService.subscribe('writeoff_update_sent', successHandler);
                socketService.subscribe('writeoff_update_error', errorHandler);
                
                // Отправляем событие
                emitSocketEvent('writeoff_update', {
                    action: 'update',
                    chatId: chatId,
                    writeOffId: writeOffId,
                    writeOffItem: {
                        name: data.name,
                        reason: data.reason,
                        quantity: data.quantity,
                        description: data.description || '',
                        unitType: data.unitType || 'шт'
                    }
                }).then((success: boolean) => {
                    if (!success && !isResolved) {
                        console.error('❌ Не удалось отправить сообщение через WebSocket');
                        isResolved = true;
                        
                        // Отписываемся от событий
                        socketService.unsubscribe('writeoff_update_sent');
                        socketService.unsubscribe('writeoff_update_error');
                        
                        // Fallback на REST API
                        fallbackToREST();
                    }
                }).catch((error: Error) => {
                    if (!isResolved) {
                        console.error('❌ Ошибка при отправке через WebSocket:', error);
                        isResolved = true;
                        
                        // Отписываемся от событий
                        socketService.unsubscribe('writeoff_update_sent');
                        socketService.unsubscribe('writeoff_update_error');
                        
                        // Fallback на REST API
                        fallbackToREST();
                    }
                });
                
                // Функция для fallback на REST API
                const fallbackToREST = () => {
                    console.log('⚠️ Fallback на REST API...');
                    axiosInstance.put(`/write-offs/${chatId}/${writeOffId}`, {
                        name: data.name,
                        reason: data.reason,
                        quantity: data.quantity,
                        description: data.description || '',
                        unitType: data.unitType || 'шт'
                    }).then(response => {
                        resolve(response.data);
                    }).catch(error => {
                        reject(error);
                    });
                };
                
                // Увеличиваем таймаут до 10 секунд
                setTimeout(() => {
                    if (!isResolved) {
                        console.warn('⚠️ Timeout на ожидание ответа от WebSocket');
                        isResolved = true;
                        
                        // Отписываемся от событий
                        socketService.unsubscribe('writeoff_update_sent');
                        socketService.unsubscribe('writeoff_update_error');
                        
                        // Fallback на REST API
                        fallbackToREST();
                    }
                }, 10000); // 10 секунд вместо 5
            });
        } else {
            console.log('📡 Используем REST API для обновления списания');
            
            // Если WebSocket не подключен, используем REST API
            return axiosInstance.put(`/write-offs/${chatId}/${writeOffId}`, {
                name: data.name,
                reason: data.reason,
                quantity: data.quantity,
                description: data.description || '',
                unitType: data.unitType || 'шт'
            }).then(response => response.data);
        }
    },
    
    // Удаление списания
    deleteWriteOff: (chatId: string, writeOffId: string) => {
        console.log('=== 📡 Удаление списания ===');
        console.log('🏠 Чат:', chatId);
        console.log('📝 ID списания:', writeOffId);
        console.log('🔗 URL запроса:', `${config.API_URL}/write-offs/${chatId}/${writeOffId}`);
        
        // Пробуем сначала через WebSocket
        if (socketService.isConnected()) {
            console.log('🔌 Используем WebSocket для удаления списания');
            
            // Для WebSocket-соединения мы будем использовать промис, который резолвится вручную
            return new Promise((resolve, reject) => {
                // Флаг для предотвращения двойного вызова resolve/reject
                let isResolved = false;
                
                // Обработчик успешного удаления списания
                const successHandler = (response: any) => {
                    console.log('✅ Ответ WebSocket (удаление):', response);
                    
                    // Предотвращаем дублирование ответа
                    if (isResolved) return;
                    isResolved = true;
                    
                    // Отписываемся от событий
                    socketService.unsubscribe('writeoff_update_sent');
                    socketService.unsubscribe('writeoff_update_error');
                    
                    // Возвращаем результат
                    resolve({ success: true });
                };
                
                // Обработчик ошибки удаления списания
                const errorHandler = (error: any) => {
                    console.error('❌ Ошибка WebSocket при удалении списания:', error);
                    
                    // Предотвращаем дублирование ответа
                    if (isResolved) return;
                    isResolved = true;
                    
                    // Отписываемся от событий
                    socketService.unsubscribe('writeoff_update_sent');
                    socketService.unsubscribe('writeoff_update_error');
                    
                    // Отклоняем промис
                    reject(error);
                };
                
                // Подписываемся на события
                socketService.subscribe('writeoff_update_sent', successHandler);
                socketService.subscribe('writeoff_update_error', errorHandler);
                
                // Отправляем событие
                emitSocketEvent('writeoff_update', {
                    action: 'delete',
                    chatId: chatId,
                    writeOffId: writeOffId
                }).then((success: boolean) => {
                    if (!success && !isResolved) {
                        console.error('❌ Не удалось отправить сообщение через WebSocket');
                        isResolved = true;
                        
                        // Отписываемся от событий
                        socketService.unsubscribe('writeoff_update_sent');
                        socketService.unsubscribe('writeoff_update_error');
                        
                        // Fallback на REST API
                        fallbackToREST();
                    }
                }).catch((error: Error) => {
                    if (!isResolved) {
                        console.error('❌ Ошибка при отправке через WebSocket:', error);
                        isResolved = true;
                        
                        // Отписываемся от событий
                        socketService.unsubscribe('writeoff_update_sent');
                        socketService.unsubscribe('writeoff_update_error');
                        
                        // Fallback на REST API
                        fallbackToREST();
                    }
                });
                
                // Функция для fallback на REST API
                const fallbackToREST = () => {
                    console.log('⚠️ Fallback на REST API...');
                    axiosInstance.delete(`/write-offs/${chatId}/${writeOffId}`)
                        .then(response => {
                            console.log('✅ Ответ сервера при удалении:', {
                                status: response.status,
                                data: response.data
                            });
                            resolve({ success: true });
                        }).catch(error => {
                            reject(error);
                        });
                };
                
                // Увеличиваем таймаут до 10 секунд
                setTimeout(() => {
                    if (!isResolved) {
                        console.warn('⚠️ Timeout на ожидание ответа от WebSocket');
                        isResolved = true;
                        
                        // Отписываемся от событий
                        socketService.unsubscribe('writeoff_update_sent');
                        socketService.unsubscribe('writeoff_update_error');
                        
                        // Fallback на REST API
                        fallbackToREST();
                    }
                }, 10000); // 10 секунд вместо 5
            });
        } else {
            console.log('📡 Используем REST API для удаления списания');
            
            // Если WebSocket не подключен, используем REST API
            return axiosInstance.delete(`/write-offs/${chatId}/${writeOffId}`)
                .then(response => {
                    console.log('✅ Ответ сервера при удалении:', {
                        status: response.status,
                        data: response.data
                    });
                    return { success: true };
                });
        }
    }
};

// История инвентаря
const historyApi = {
    getItemHistory: async (chatId: string, itemId: string, category: string, itemName: string) => {
        console.log('=== 📡 Запрос истории ===');
        console.log('🏠 Чат:', chatId);
        console.log('📦 Товар:', itemName);
        console.log('📑 Категория:', category);
        console.log('🆔 ID товара:', itemId);
        
        const url = `/item_history/${chatId}/${encodeURIComponent(category)}/${encodeURIComponent(itemName)}`;
        console.log('🔗 URL запроса:', url);
        console.log('🔗 Полный URL:', `${config.API_URL}${url}`);
        
        return axiosInstance.get(url);
    },

    addHistoryRecord: async (chatId: string, itemId: string, data: {
        action: string;
        type: 'raw' | 'semifinished';
        quantity: number;
        oldQuantity: number;
        newQuantity: number;
    }) => {
        return axiosInstance.post(`/item_history/${chatId}`, data);
    },

    getHistoryByDateRange: async (chatId: string, itemId: string, startDate: string, endDate: string) => {
        return axiosInstance.get(`/item_history/${chatId}/range`, {
            params: { startDate, endDate }
        });
    }
};

// Пользователи
const userApi = {
    getCurrentUser: () => {
        console.log('=== 📡 Запрос данных пользователя ===');
        console.log('🔗 URL:', `${config.API_URL}/users/me`);
        return axiosInstance.get('/users/me');
    }
};

// Интерцептор для логирования запросов
axiosInstance.interceptors.request.use(
    config => {
        console.log('🚀 API Request:', {
            method: config.method?.toUpperCase(),
            url: config.url,
            baseURL: config.baseURL,
            fullURL: `${config.baseURL}${config.url}`,
            data: config.data
        });
        return config;
    },
    error => {
        console.error('❌ API Request Error:', error);
        return Promise.reject(error);
    }
);

// Интерцептор для обработки ошибок
axiosInstance.interceptors.response.use(
    response => response,
    error => {
        console.error('API Error:', {
            url: error.config?.url,
            method: error.config?.method,
            status: error.response?.status,
            data: error.response?.data,
            message: error.message
        });
        if (error.response?.data?.message) {
            throw new Error(error.response.data.message);
        }
        throw error;
    }
);

// Экспортируем API
export const api = {
    writeOff: writeOffApi,
    history: historyApi,
    user: userApi
};

const API_BASE_URL = config.API_URL;

export interface UpdateProfileData {
    firstName: string;
    lastName: string;
    isSeniorCourier?: boolean;
    seniorPassword?: string;
    chatId?: string;
}

export const updateCourierProfile = async (userId: number, data: UpdateProfileData) => {
    try {
        console.log('📡 Отправка запроса на обновление профиля:', {
            url: `${API_BASE_URL}/courier/profile/${userId}`,
            data: data
        });

        const response = await axios.put(`${API_BASE_URL}/courier/profile/${userId}`, {
            firstName: data.firstName,
            lastName: data.lastName,
            isSeniorCourier: data.isSeniorCourier,
            seniorPassword: data.seniorPassword,
            chatId: data.chatId
        });
        console.log('✅ Профиль успешно обновлен:', response.data);
        return response.data;
    } catch (error) {
        console.error('❌ Ошибка при обновлении профиля:', error);
        
        if (axios.isAxiosError(error)) {
            if (error.code === 'ERR_NETWORK') {
                throw new Error('Ошибка сети. Пожалуйста, проверьте подключение к интернету');
            }
            if (error.response?.status === 403) {
                throw new Error('Доступ запрещен. У вас нет прав для выполнения этого действия');
            }
            if (error.response?.status === 404) {
                throw new Error('Пользователь не найден в группах курьеров');
            }
            if (error.response?.status === 401) {
                throw new Error('Неверный пароль старшего курьера');
            }
            throw new Error(error.response?.data?.error || 'Ошибка при обновлении профиля');
        }
        
        throw new Error('Произошла неизвестная ошибка');
    }
}; 